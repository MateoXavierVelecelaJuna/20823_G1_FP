#include <stdio.h>
#include "mimath.h"
#include "factorial.h"
#include "operaciones.h"

/*UNIVERSIDAD DE LAS FUERZAS ARMADAS "ESPE"
GRUPO 1
NOMBRES: ANTHONY CAMPOVERDE, MATEO VELECELA, ALEXANDER ALVEAR
CALCULADORA, FIBONACCI, MODULOS, EN LIBRERIAS
TALLER 8 */

int main() {
    float a = 16.0 , b =8.0  ;
    printf("Suma: %.2f\n", suma(a, b));
    printf("Resta: %.2f\n", resta(a, b));
    printf("Multiplicacion: %.2f\n", multiplicacion(a, b));
    printf("division: %.2f\n", division(a, b));


    int n = 9;
    printf("Fibonacci(%d) = %d\n", n, fibonacci(n));


    int x = 12, y = 3;
    printf("Multiplicar: %d\n", multiplicar(x, y));
    printf("Dividir: %d\n", dividir(x, y));

    return 0;


}
