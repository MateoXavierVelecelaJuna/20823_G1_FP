#ifndef OPERACIONES_H
#define OPERACIONES_H

int multiplicar(int a, int b);
int dividir(int a, int b);

#endif
