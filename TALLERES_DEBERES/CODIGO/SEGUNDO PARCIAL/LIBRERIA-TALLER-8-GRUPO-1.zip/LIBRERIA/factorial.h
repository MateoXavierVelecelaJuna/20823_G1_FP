#ifndef FACTORIAL_H
#define FACTORIAL_H

int fibonacci(int n);

#endif
